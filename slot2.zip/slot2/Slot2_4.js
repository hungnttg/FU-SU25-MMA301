import { useState } from "react";
import { Text, TextInput, View } from "react-native";
const Slot2_4 = () =>{
    const [hoten,setHoten] = useState('');
    return(
        <View>
            <TextInput placeholder="Moi nhap ho ten"
                        onChangeText={hoten => setHoten(hoten)}
                        defaultValue={hoten} />
            <Text>Ban vua nhap: {hoten}</Text>
        </View>
    );
}
export default Slot2_4;