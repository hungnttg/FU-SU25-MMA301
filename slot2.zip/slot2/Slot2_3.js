//Component Con 
import React from "react";
import { Text, View } from "react-native";
export default class Slot2_3 extends React.Component{
    render(){
        return(
            <View>
                <Text>Ten vua nhap la: {this.props.Ten}</Text>
            </View>
        );
    }
}