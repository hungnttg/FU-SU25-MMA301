import React from "react";
import { Text, View } from "react-native";
export default class Slot2_1 extends React.Component{
    //code
    constructor(){
        super();
        this.state = {
            dem: 0,
            text: "click me",
        };
    }
    updateText(){
        this.setState((preState)=>{
            return {
                dem: preState.dem + 1,
                text: 'ban vua click lan ',
            }
        });
    }
    //layout
    render(){
        return(
            <View>
                <Text
                    onPress={()=>this.updateText()}
                >{this.state.text} : {this.state.dem}</Text>
            </View>
        );
    }
}