import { View } from "react-native";
import Con from "./Slot2_6Con";
export default function Cha(){
    const userName = 'Nguyen Van A';
    return(
        <View>
            <Con name={userName}/>
        </View>
    );
}