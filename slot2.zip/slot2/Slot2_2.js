//Component Cha
import { useState } from "react";
import { Text, TextInput, View } from "react-native";
import Slot2_3 from "./Slot2_3";
//import thanh phan Con
//dinh nghia props
const SuDungProps = (props) =>{
    return(
        <TextInput {...props} editable maxLength={100} />
    );
}
//dinh nghia state
const SuDungState = () =>{
    //khai bao su dung state
    const [giatri,hamThayDoiGiaTri] = useState('');
    return(
        <View>
            {/* cach 1 ----------------------------------*/}
            {/* su dung props trong view cua state */}
            <SuDungProps
                onChangeText = {text => hamThayDoiGiaTri(text)} value={giatri}
            />
            {/* cach 2 ------------------------------------*/}
            {/* goi state */}
            <Text>Gia tri moi la: {giatri}</Text>
            {/* goi va truyen du lieu cho thanh phan con */}
            <Slot2_3 Ten={giatri}/>
        </View>
    );
}
export default SuDungState;