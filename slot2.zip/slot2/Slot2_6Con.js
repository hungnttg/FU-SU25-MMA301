import { Text, View } from "react-native";
export default function Con({name}){
    return(
        <View>
            <Text>Xin chao , {name}</Text>
        </View>
    );
}