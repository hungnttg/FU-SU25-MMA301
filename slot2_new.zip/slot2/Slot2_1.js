//dem so lan click bang function
import { useState } from "react";
import { Button, Text, View } from "react-native";
export default function Slot2_1(){
    //code
    const [count,setCount]= useState(0);
    //layout
    return(
        <View>
            <Text>Ban click {count} lan.</Text>
            <Button title="Click me" onPress={()=>setCount(count+1)}/>
        </View>
    );
    
}