import React,{useState} from "react";
import { Text,View,TextInput } from "react-native";
const Slot2_5_Con = ({onTextSubmit}) =>{
    //code
    const [ten,setTen]=useState('');
    const handleSubmit = () =>{
        if(onTextSubmit){
            onTextSubmit(ten);//truyen du lieu qua props
        }
    };
    //layout
    return(
        <View>
            <TextInput
                placeholder="Moi nhap ten vao Component Con"
                onChangeText={(ten)=>setTen(ten)}
                onSubmitEditing={handleSubmit}
            />
            <Text>Ban vua nhap: {ten}</Text>
        </View>
    );

}
export default Slot2_5_Con;