import React from "react";
import { Button, Text, View } from "react-native";
export default class Slot2_2 extends React.Component{
    //code
    constructor(){
        super();
        this.state = {
            text: "click me",
            count: 0,
        };
    }
    updateText(){
        this.setState((pre)=>{
            return {
                 count: pre.count +1,
                 text: 'ban vua click lan ',
            }     
        });
    }
    //layout
    render(){
        return(
            <View>
                <Text onPress={()=>this.updateText()}>Ban click {this.state.count} lan</Text>
                <Button title="Dem so lan click" onPress={()=>this.updateText()}/>
            </View>
        );
    }
}