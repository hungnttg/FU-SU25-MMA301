import React,{useState} from "react";
import { View,Text,TextInput } from "react-native";
import Slot2_3_Con from "./Slot2_3_Con";
const Slot2_3_Cha = () =>{
    //const userName = 'Nguyen Van A';
    const [giaTri,setGiaTri]=useState('');
    return(
        <View>
             <TextInput placeholder="Xin moi nhap ho ten"
            onChangeText={(giaTri)=>setGiaTri(giaTri)}
            defaultValue={giaTri}/>
            <Slot2_3_Con name={giaTri}/>
        </View>
    );
}
export default Slot2_3_Cha;