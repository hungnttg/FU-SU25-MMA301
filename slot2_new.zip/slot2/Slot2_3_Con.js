//
import { Text, View } from "react-native";
const Slot2_3_Con = ({name}) =>{
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}
export default Slot2_3_Con;