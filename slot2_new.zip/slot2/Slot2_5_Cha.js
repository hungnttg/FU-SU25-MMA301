import React,{useState} from "react";
import { Text,View } from "react-native";
import Slot2_5_Con from "./Slot2_5_Con";
const Slot2_5_Cha = ()=>{
    //code
    const [receivedText,setReceivedText] = useState('');
    const handleTextSubmit = (text) =>{
        setReceivedText(text);
    };
    //layout
    return(
        <View>
            <Slot2_5_Con onTextSubmit={handleTextSubmit} />
            <Text>Du lieu nhan duoc: {receivedText}</Text>
        </View>
    );

}
export default Slot2_5_Cha;