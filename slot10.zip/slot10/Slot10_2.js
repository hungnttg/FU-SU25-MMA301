import React,{useState,memo,useCallback,useEffect} from "react";
import { Text,View,Button,StyleSheet } from "react-native";
// header
const Header = memo(({title}) => {
    console.log('Rendering header');
    return(
        <View style={styles.header}>
            <Text style={styles.headerText}>{title}</Text>
        </View>
    );
});
// footer
const Footer = memo(({year})=>{
     console.log('Rendering footer');
     return(
        <View styles={styles.footer}>
            <Text style={styles.footerText}>{year}</Text>
        </View>
     );
});
// body
const Slot10_2 = () =>{
    const [count,setCount]=useState(0);
    //thuc hien callback
    const increment = useCallback(()=>{
        setCount((prevCount)=> prevCount+1);
    });
    useEffect(()=>{

    },[count]);
    return(
        <View style={styles.container}>
            <Header title="My App"/>
            <View style={styles.main}>
                <Text style={styles.countText}>Count:{count}</Text>
                <Button title="Increment" onPress={increment} />
            </View>
            <Footer year={new Date().getFullYear()} />
        </View>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'#fff',
    },
    main:{
        alignItems:'center',
        marginVertical: 20,
    },
    countText:{
        fontSize:20,
        marginBottom:20,
    },
    header:{
        backgroundColor:'lightblue',
        padding:10,
        alignItems:'center',
        width:'100%',
    },
    headerText:{
        fontSize:20,
        fontWeight:'bold',
    },
    footer:{
        backgroundColor:'lightblue',
        width:'100%',
        padding:10,
        alignItems:'center',
    },
    footerText:{
        fontSize:15,
    },
});
export default Slot10_2;
