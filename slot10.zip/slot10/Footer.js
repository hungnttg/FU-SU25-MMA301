import React from "react";
import { View,Text,StyleSheet } from "react-native";
const Footer = ({info}) =>{
    return(
        <View style={styles.footer}>
            <Text style={styles.footerText}>{info}</Text>
        </View>
    );
};
const styles = StyleSheet.create({
    footer:{
        backgroundColor:'red',
        padding:10,
    },
    footerText:{
        fontSize:16,
        textAlign:'center',
    },
});
export default Footer;