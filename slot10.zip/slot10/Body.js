import React,{useState} from "react";
import { Text,View,Button,StyleSheet, TextInput } from "react-native";
const Body = ({onSubmit}) =>{
    const [inputValue,setInputValue] = useState('');
    const handleSubmit = () =>{
        onSubmit(inputValue);//ham nhan tham so la inputValue
        setInputValue('');//sau khi truyen gia tri thi reset lai
    };
    return(
        <View style={styles.body}>
            <TextInput
                style = {styles.input}
                placeholder="Nhap thong tin"
                value={inputValue}
                onChangeText={setInputValue}
            />
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );
};
const styles=StyleSheet.create({
    body:{
        padding:20,
    },
    input:{
        height:40,
        borderColor:'gray',
        borderWidth:1,
        marginBottom: 10,
        paddingLeft:10,
    },
});
export default Body;