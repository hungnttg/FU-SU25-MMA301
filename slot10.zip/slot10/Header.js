import React from "react";
import {Text,View,StyleSheet} from 'react-native';
const Header = () =>{
    return(
        <View style={styles.header}>
            <Text style={styles.headerText}>Header Component</Text>
        </View>
    );
};
const styles = StyleSheet.create({
    header:{
        backgroundColor:'red',
        padding:10,
    },
    headerText:{
        fontSize:30,
        fontWeight:'bold'
    },
});
export default Header;