//npm i @react-navigation/stack
//npm i @react-navigation/native
import React,{useState,useEffect} from "react";
import { FlatList } from "react-native";
import ProductFn from "./Product61";
import { useNavigation, useRoute } from '@react-navigation/native';
import {} from '@react-navigation/stack';
const ListProductFn = () =>{
    //1. code
    const navigation=useNavigation();//su dung de dieu huong
    const route = useRoute();
    const [prd,setPrd]=useState(null);
    //ham ket xuat du lieu
    const renderItemFlatList = ({item}) =>{
        return(
            <ProductFn dataProd={item} handlePress={()=>viewDetail(item)}/>
        );
    };
    //ham hien thi chi tiet
    const viewDetail = (p)=>{
        navigation.navigate('DetailFn',{data:p});
    };
    //ham doc du lieu tu API
    const getProducts = async () =>{
        const url = 'https://hungnttg.github.io/shopgiay.json';//duong dan
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const responseJSON = await response.json();//chuyen sang json
        //cap nhat vao state
        setPrd(responseJSON.products);
    };
    //goi ham doc du lieu
    useEffect(()=>{
        getProducts();
    },[]);
    //2.layout
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatList}
            numColumns={3}
            removeClippedSubviews
        />
    );

}
export default ListProductFn;