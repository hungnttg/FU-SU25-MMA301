import DetailFn from "./Detail61";
import ListProductFn from "./ListProduct61";
import CartFn from "./CartFn";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
const Stack = createStackNavigator();
const NavFn = () =>{
    return(
       
            <Stack.Navigator initialRouteName="ListProductFn">
                <Stack.Screen name="ListProductFn" component={ListProductFn}/>
                <Stack.Screen name="DetailFn" component={DetailFn}/>
                <Stack.Screen name="CartFn" component={CartFn}/>
            </Stack.Navigator>
        
    );
}
export default NavFn;