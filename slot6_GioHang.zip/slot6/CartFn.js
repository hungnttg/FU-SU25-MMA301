import React,{useState} from "react";
import { View,ScrollView,Button,FlatList,Text } from "react-native";
import ProductFn from "./Product61";
global.myCart=[];
const CartFn = ({route}) =>{
    //code
    const [count,setCount]=useState(1);
    const [list,setList]=useState(global.myCart);
    const data = route.params?.data || ""; //nhan du lieu tu DetailFn
    //lay toan bo san pham trong gio hang (getProducts)
    const allProductInCart = () =>{
        const newList = [{data},...global.myCart];
        global.myCart = newList;//cap nhat danh sach moi len myCart
        setList([...newList]);//cap nhat state
    };
    //ket xuat du lieu trong gio hang
    const renderItemCart=({index,item})=>{
        return(
            <ProductFn dataProd={global.myCart[index].data} /> 
        );
    };
    //layout
    return(
        <View>
            <ScrollView>
                {/* san pham vua them vao gio hang */}
                <ProductFn dataProd={data}/>
                {/* thay doi so luong */}
                <Button title="+" onPress={()=>setCount(count+1)}/>
                <Text>So luong san pham: {count}</Text>
                <Button title="-" onPress={()=>setCount(count-1)}/>
                <Button title="Get All P in Cart" onPress={allProductInCart}/>
                {/* flatlist hien thi toan bo gio hang */}
                <FlatList
                    data={list}
                    renderItem={renderItemCart}
                    numColumns={2}
                    removeClippedSubviews
                />

            </ScrollView>
        </View>
    );
}
export default CartFn;