import React from "react";
import { Text,View,Button,TouchableOpacity } from "react-native";
//npm i @react-navigation/drawer
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import {} from '@react-navigation/native';
import { Ionicons } from "@expo/vector-icons";
const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

const HomeScreen = ({navigation}) =>{
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
        <TouchableOpacity onPress={()=>navigation.openDrawer()}
            style={{position:'absolute',left:20,top:50}}>
                <Ionicons name="menu" size={30} color="black"/>
        </TouchableOpacity>
        <Text>Home Screen</Text>
    </View>
};
const SettingsScreen = () =>{
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
        <Text>Settings Screen</Text>
    </View>
};
export default function Slot14_2(){
    return(
        <Drawer.Navigator initialRouteName="Home">
            <Drawer.Screen name="Home" component={HomeScreen}/>
            <Drawer.Screen name="Settings" component={SettingsScreen}/>
        </Drawer.Navigator>
    );
}