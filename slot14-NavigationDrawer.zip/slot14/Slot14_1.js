//npm i @react-navigation/native
//npm i @react-navigation/bottom-tabs react-native-screens react-native-safe-area-context
//npm i @expo/vector-icons
//npx expo install react-dom react-native-web @expo/metro-runtime
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { Text,View } from "react-native";
//khai bao cac Tab
const Tab = createBottomTabNavigator();
// dinh nghia cac man hinh
function HomeScreen(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            {/* doc du lieu o day */}
            <Text>Home</Text>
        </View>
    );
}
function SettingsScreen(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            {/* du lieu doc doc o day */}
            <Text>Settings</Text>
        </View>
    );
}
function InfoScreen(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            {/* du lieu doc doc o day */}
            <Text>Info</Text>
        </View>
    );
}
// dinh nghia phan App
export default function Slot14_1(){
    return(
  
            <Tab.Navigator>
                <Tab.Screen 
                    name="Home"
                    component={HomeScreen}
                    options={{
                        tabBarIcon: ({color,size}) =>(
                            <Ionicons name="home" size={size} color={color} />
                        ),
                    }}
                />
                <Tab.Screen 
                    name="Settings"
                    component={SettingsScreen}
                    options={{
                        tabBarIcon: ({color,size}) =>(
                            <Ionicons name="settings" size={size} color={color} />
                        ),
                    }}
                />
                <Tab.Screen 
                    name="Info"
                    component={InfoScreen}
                    options={{
                        tabBarIcon: ({color,size}) =>(
                            <Ionicons name="information" size={size} color={color} />
                        ),
                    }}
                />
            </Tab.Navigator>
  
    );
}