//npx expo install expo-dev-client
//npx expo install @react-native-firebase/app
//insert du lieu vao firebase
import React,{useState} from "react";
import { Text,View,Button,TextInput } from "react-native";
import { collection,addDoc, doc, updateDoc, deleteDoc } from "firebase/firestore";
import { FIRESTORE_DB } from "../../firebaseConfig";
const Slot16 = () =>{
    const [text,setText]=useState('');
    const [id,setId]=useState('');
    const handleAddData = async () =>{
        try {
            const docRef = await addDoc(collection(FIRESTORE_DB,'items'),{
                text: text
            });
            console.log('Doccument written with ID: ',+docRef.id);
            setText('');
        } catch (error) {
            console.error('Error adding document: ',error);
        }
    };
    const handleUpdateData = async (itemId,newText) =>{
        try {
            //itemId = '8Ew4ondvuvQs6MyCsmN7';
            const itemDoc = doc(FIRESTORE_DB,'items',itemId);
            await updateDoc(itemDoc,{text:newText});
            console.log('Updated with ID: ',itemDoc.id);
            setText('');
        } catch (error) {
            console.error('Error: ',error);
        }
    };
    const handleDeleteData = async (itemId)=>{
        try {
            const itemDoc = doc(FIRESTORE_DB,"items",itemId);
            await deleteDoc(itemDoc);
            console.log("Delete thanh cong: "+itemId);
        } catch (error) {
            console.error(error);
        }
    };
    return(
        <View>
            <TextInput placeholder="Enter Text" value={text} onChangeText={setText}/>
            <Button title="Add Data" onPress={handleAddData}/>
            <TextInput placeholder="Nhap id" value={id} onChangeText={setId}/>
            <Button title="Update Data" onPress={()=>handleUpdateData(id,text)}/>
            <Button title="Delete Data" onPress={()=>handleDeleteData(id)}/>
        </View>
    );
}
export default Slot16;