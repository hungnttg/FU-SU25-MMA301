// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBwpepe404aQiQN144h38SFSU_sHj0Eqi9c",
  authDomain: "hungnq401-fb6d8.firebaseapp.com",
  projectId: "hungnq401-fb6d8",
  storageBucket: "hungnq401-fb6d8.firebasestorage.app",
  messagingSenderId: "2328003867061",
  appId: "1:232800386706:web:1a0b6d6c0012874640704b1",
  measurementId: "G-3T7E08Q1Z0G"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const FIRESTORE_DB = getFirestore(app);
//const analytics = getAnalytics(app);