//npm i react-native-maps@1.18.0
//chi chay tren mobile
//can xoa thu vien nay di neu muon su dung moi truong web
import React,{useState} from "react";
import { View,Text,StyleSheet } from "react-native";
import MapView, {Marker} from 'react-native-maps';
const Slot18 = () =>{
    const [coordinate,setCoordinate]=useState({
        // vi tri mac dinh cua ha noi
        latitude: 21.0278,
        longitude: 105.8342
    });
    const handleMapPress = (e) =>{
        const {latitude, longitude} = e.nativeEvent.coordinate;
        setCoordinate({latitude,longitude});
    };
    return(
        <View style={styles.container}>
            <MapView
                style={styles.map}
                initialRegion={{
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01
                }}
                onPress={handleMapPress}
            >
                <Marker coordinate={coordinate} title="Vi tri Ha noi"/>
            </MapView>
            <View style={styles.infoBox}>
                <Text style={styles.text}>Vi do: {coordinate.latitude.toFixed(6)}</Text>
                <Text style={styles.text}>Kinh do: {coordinate.longitude.toFixed(6)}</Text>
            </View>
        </View>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
    },
    map: {
        flex:1,
    },
    infoBox: {
        padding:10,
        backgroundColor:'white',
        alignItems:'center',
    },
    text:{
        fontSize:18,
        fontWeight:'bold',
    },
});
export default Slot18;