<?php
header('Access-Control-Allow-Origin:*');//cho phep truy cap
$s="localhost"; $u="root"; $p="";$db="a5";//khai bao thong tin csdl
$conn = new mysqli($s,$u,$p,$db);//mo ket noi csdl
$result = $conn -> query("select * from mytable");//truy van du lieu
while($row[] = $result->fetch_assoc()){//doc tung dong, dua vao mang
    $json = json_encode($row);//chuyen sang json
}
echo '{"products":'.$json.'}';//print
$conn->close();//dong ket noi