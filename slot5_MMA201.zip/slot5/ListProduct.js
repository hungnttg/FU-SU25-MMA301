import React from "react";
import { FlatList } from "react-native";
import Product from "./Product";
export default class ListProduct extends React.Component{
    //code
    constructor(props){
        super(props);
        this.state={
            products: null, //danh sach san pham
        };
        //binding cac ham
        this.getProducts = this.getProducts.bind(this);
        this.renderItem=this.renderItem.bind(this);
    }
    //ham doc du lieu tu API
    async getProducts(){
        const url='https://hungnttg.github.io/shopgiay.json';//link doc du lieu
        let response = await fetch(url,{method:'GET'});//doc du lieu voi phuong thuc get
        let responseJSON = await response.json();//chuyen sang json
        //cap nhat vao state
        this.setState({
            products: responseJSON.products,
        });
    }
    //goi ham doc du lieu khi chay: componentDidMount: la 1 ham co san
    componentDidMount(){
        this.getProducts();
    }
    //ham tao view de hien thi du lieu
    renderItem({item}){
        return(
            <Product dataProd={item} />
        );
    }
    //layout
    render(){
        return(
            <FlatList
                data={this.state.products}
                renderItem={this.renderItem}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }
}