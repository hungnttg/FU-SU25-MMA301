import { StyleSheet, Text, View } from "react-native";
const Slot1_2 = () =>{
    return(
        <View>
            <Text>Day la version Function</Text>
        </View>
    );
}
export default Slot1_2;
const styles = StyleSheet.create({
    
});