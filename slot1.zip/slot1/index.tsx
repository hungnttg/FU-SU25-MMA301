import React from 'react';
import { StyleSheet, View } from 'react-native';
//import Slot1_1 from '../../src/slot1/Slot1_1';
import Slot1_2 from '../../src/slot1/Slot1_2';

export default function HomeScreen() {
  return (
      <View>
          {/* <Slot1_1/> */}
          <Slot1_2/>
      </View>
  );
}

const styles = StyleSheet.create({
  
});
