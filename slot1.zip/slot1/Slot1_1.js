import React from "react";
import { Text, View } from "react-native";
export default class Slot1_1 extends React.Component {
    render(){
        return(
            <View>
                <Text>Day la version class</Text>
            </View>
        );
    }
}