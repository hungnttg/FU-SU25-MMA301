//vòng lặp + funtion
import React,{useState} from "react";
import { Text,View,TouchableOpacity,StyleSheet } from "react-native";
const Slot4_1 = () =>{
    //code
    const [calculation,setCalculation]=useState('');
    const [result,setResult]=useState('');
    //process when you press button
    //case 1: press the '=' button
    //case 2: else buttons
    const pressButton = (text) =>{
        if(text === "="){
            try {
                setResult(eval(calculation).toString());//calculate result
                setCalculation('');//reset calculation variable
            } catch (error) {
                setResult('Error: '+error.toString());
            }
        }
        else {
            setCalculation((prev) =>prev + text);
        }
    };
    //Function for control operation buttons
    const operate = (op) =>{
        if(op === 'DEL') //equals the 'DEL' button
        {
            setCalculation(prev => prev.slice(0,-1));//delete last character
        }
        else { // not equals the 'DEL' button
            setCalculation(prev => prev + op); //add operation to expression
        }
    };
    //layout
    const renderNumberButtons = () =>{ //render the number part
        const nums=[[1,2,3],[4,5,6],[7,8,9],['.','0','=']];//3 cols, 4 rows
        return nums.map((row,i)=>(
            <View key={i} style={styles.row}>
                {
                    row.map((num)=>(
                        <TouchableOpacity key={num} style={styles.btn}
                            onPress={()=>pressButton(num.toString())}
                        >
                            <Text style={styles.txt}>{num}</Text>
                        </TouchableOpacity>
                    ))
                }
            </View>
        ));
    };
    const renderOperationButtons = () =>{
        const ops = ['+','-','*','/','DEL'];
        return ops.map((op)=>(
            <TouchableOpacity key={op} style={styles.btn}
                onPress={()=>operate(op)}
            >
                <Text style={styles.txt}>{op}</Text>
            </TouchableOpacity>
        ));
    };
    return(
        <View style={styles.container}>
            <View style={styles.resultText}>
                <Text style={styles.txt}>{result}</Text>
            </View>
            <View style={styles.calculationText}>
                <Text style={styles.txt}>{calculation}</Text>
            </View>
            <View style={styles.buttons}>
                <View style={styles.numberButtons}>
                    {renderNumberButtons()}
                </View>
                 <View style={styles.operationButtons}>
                    {renderOperationButtons()}
                </View>
            </View>
        </View>
    );

};
export default Slot4_1;
const styles = StyleSheet.create({
    //child components of Container
    container:{
        flex:1, flexDirection:'column',backgroundColor:'yellow',
    },
    resultText:{
        flex:1, backgroundColor:'green',
        justifyContent:'center',alignItems:'center',
    },
    calculationText:{
        flex:2, backgroundColor:'#AAA111',
        justifyContent:'center',alignItems:'center',
    },
    buttons:{
        flex:7, flexDirection:'row', backgroundColor:'pink',
    },
    //child components of buttons
    numberButtons:{
        flex:3, backgroundColor:'#AAA222',justifyContent:'space-around',
    }, 
    operationButtons:{
        flex:1,backgroundColor:'#BBB111',justifyContent:'space-around',
    },
    //chile components of numberButtons
    row:{
        flexDirection:'row',justifyContent:'space-around'
    },
    btn:{
        flex:1,backgroundColor:'#CCC111',justifyContent:'center',
        alignItems:'center',padding:20,
    },
    txt:{
        fontSize:30,fontWeight:'bold',
    },
});