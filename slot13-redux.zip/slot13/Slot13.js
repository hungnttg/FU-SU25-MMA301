import React from "react";
import { View } from "react-native";
import { Provider } from "react-redux";
import store from "./store";
import ProductList from "./ProductList";
import Cart from "./Cart";
// khai bao mang, co the doc API o day
const products = [
    {id:1,name: "product 1"},
    {id:2,name: "product 2"},
    {id:3,name: "product 3"},
    {id:4,name: "product 4"},
];
// 
const Slot13 = ()=>{
    return(
        <Provider store={store}>
            <View>
                <ProductList products={products}/>
                <Cart/>
            </View>
        </Provider>
    );
}
export default Slot13;