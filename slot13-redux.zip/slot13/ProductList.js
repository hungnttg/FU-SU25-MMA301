import React from "react";
import { View,Button,Text } from "react-native";
import { useDispatch } from "react-redux";//phan phoi trang thai
import { addItem } from "./actions";

const ProductList = ({products})=>{
    const dispatch = useDispatch();//dung de phan phoi trang thai den view
    return(
        <View>
            {products.map(product => (
                <View key={product.id}>
                    <Text>{product.name}</Text>
                    <Button title="Add to Cart" onPress={()=>dispatch(addItem(product))} />
                </View>
            ))}
        </View>
    );
};
export default ProductList;