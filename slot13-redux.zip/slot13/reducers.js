import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";
// khoi tao cac trang thai
const initialState = {items: []};
const cartReducer = createReducer(initialState,builder => {
    //cac ham xu ly se duoc dinh nghia o day
    builder
    // dinh nghia ham addItem
    .addCase(addItem,(state,action)=>{
        //lay ve id cua san pham
        const existingItemIndex = state.items.findIndex(item => item.id === action.payload.id);
        if(existingItemIndex !== -1){//neu san pham da ton tai
            state.items[existingItemIndex].quantity++; //so luong tang len 1
        }
        else {
            //neu chua ton tai san pham => them san pham vao gio hang va set so luong la 1
            state.items.push({...action.payload,quantity:1});
        }
    })
    //dinh nghia ham xoa san pham khoi gio hang
    .addCase(removeItem,(state,action)=>{
        //lay ve id san pham
        const existingItemIndex = state.items.findIndex(item => item.id === action.payload.id);
        //kiem tra id san pham co ton tai khong
        if(existingItemIndex !== -1){
            state.items[existingItemIndex].quantity--;//neu ton tai thi giam so luong 
            //kiem tra: neu da giam het so luong san pham
            if(state.items[existingItemIndex].quantity === 0){
                state.items.splice(existingItemIndex,1);//loai bo san pham
            }
        }
    });
});
export default cartReducer;