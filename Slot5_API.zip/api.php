<?php
header('Access-Control-Allow-Origin:*');//cap quyen truy cap
$s="localhost";$u="root";$p="";$db="a6";//thong tin ve csdl
$conn = new mysqli($s,$u,$p,$db);//ket noi voi csdl
$result = $conn->query("select * from mytable");//truy van du lieu
while($row[]= $result->fetch_assoc()){//doc tung dong
    $json=json_encode($row);//chuyen sang json
}
echo '{"products":'.$json.'}';//in ra man hinh
$conn->close();//dong ket noi