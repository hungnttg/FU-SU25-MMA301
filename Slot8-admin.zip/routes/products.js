const express = require('express');
const router = express.Router();
const Product =  require('../models/Product');
//hien thi danh sach san pham
router.get('/admin',async (req,res)=>{
    try {
        const products=await Product.find();//lay ve tat ca cac san pham
        res.render('admin',{products,product:null});
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//them san pham
router.post('/add-product',async (req,res)=>{
    const {id,name,price,description}=req.body;//lay du lieu nguoi dung nhap
    //tao 1 san pham moi voi du lieu nguoi dung nhap
    const newProduct = new Product({id,name,price,description});
    try {
        await newProduct.save();//insert vao collection Product
        res.redirect('/admin');//chuyen huong ve trang admin
    } catch (error) {
         res.status(500).send(error.message);
    }
});
//edit san pham
router.get('/edit-product/:id',async (req,res)=>{
    try {
        //lay du lieu cua 1 san pham va dua len form
        const product = await Product.findById(req.params.id);//lay 1 san pham theo id
        const products = await Product.find();//lay tat ca cac san pham
        res.render('admin',{product,products});//dua du lieu len form
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//update san pham
router.post('/edit-product/:id',async (req,res)=>{
    const {name,price,description}=req.body;//lay di lieu do nguoi dung cap nhat
    try {
        //thuc hien update
        await Product.findByIdAndUpdate(req.params.id,{name,price,description});
        res.redirect('/admin');//chuyen huong ve trang admin

    } catch (error) {
         res.status(500).send(error.message);
    }
});
//xoa san pham
router.post('/delete-product/:id',async (req,res)=>{
    try {
        await Product.findByIdAndDelete(req.params.id);//thuc hien xoa
        res.redirect('/admin');//chuyen huong ve trang admin
    } catch (error) {
        res.status(500).send(error.message);
    }
});
module.exports = router;