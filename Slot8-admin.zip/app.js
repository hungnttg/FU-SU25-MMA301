const express = require('express');
const mongoose = require('mongoose');
//npm i body-parser
const bodyParser = require('body-parser');
const productRouters = require('./routes/products');
//tao app
const app = express();
//cau hinh view ejs
app.set('view engine','ejs');
//middleware
app.use(bodyParser.urlencoded({extended:true}));
//ket noi mongo
mongoose.connect('mongodb://localhost:27017/a1',{

}).then(()=>{
    console.log('Ket noi voi mongodb thanh cong');
}).catch(err=>{
    console.log('Key noi that bau: ',err.message);
});
//su dung route quan tri san pham
app.use('/',productRouters);
//lang nghe
app.listen(3000,()=>{
    console.log('Server dang lang nghe o cong 3000');
});