import React,{useState,useEffect} from "react";
import {Text,View,TextInput,Button,FlatList} from 'react-native';
import { collection, deleteDoc, doc, onSnapshot, updateDoc,addDoc } from 'firebase/firestore';
import { FIRESTORE_DB } from '../../../firebaseConfig';
const ITEMS_COLLECTION = collection(FIRESTORE_DB,'items');
const Slot16_1 = () =>{
    const [text,setText]=useState('');
    const [items,setItems]=useState([]);
    useEffect(()=>{
        const unsubcribe = onSnapshot(ITEMS_COLLECTION,(snapshot)=>{
            const updatedItems = [];
            snapshot.forEach((doc)=>{
                updatedItems.push({id:doc.id,...doc.data()});
            });
            setItems(updatedItems);
        });
        return () =>unsubcribe();
    },[]);
    //ham them du lieu vao firebase
    const handleAddData = async () =>{
        try {
            await addDoc(ITEMS_COLLECTION,{
                text: text
            });
            setText('');
        } catch (error) {
            console.error('Error adding document: ',error);
        }
    };
    //ham update du lieu
    const handleUpdateData = async (itemId,newText) =>{
        try {
            const itemDoc = doc(FIRESTORE_DB,'items',itemId);
            await updateDoc(itemDoc,{text: newText});
        } catch (error) {
            console.error('Error updating document: ',error);
        }
    };
    //ham xoa du lieu tu firebase
    const handleDeleteData = async (itemId) =>{
        try {
            const itemDoc = doc(FIRESTORE_DB,'items',itemId);
            await deleteDoc(itemDoc);
        } catch (error) {
            console.error('Error deleting document: ',error);
        }
    };
    //hien thi du lieu voi firebase
    const renderItem = ({item}) =>(
        <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:10,
            alignItems:'center'}}>
            <TextInput
                style = {{flex:1,marginRight:10}}
                value={item.text}
                onChangeText={(newText)=> handleUpdateData(item.id,newText)}
            />
            <Button title="Delete" onPress={()=>handleDeleteData(item.id)}/>
        </View>
    );
    //---layout---
    return(
        <View style={{flex:1,padding:20}}>
            <TextInput
                placeholder="Enter Text..."
                value={text}
                onChangeText={setText}
                style={{marginBottom: 10}}
            />
            <Button
                title="Add Data"
                onPress={handleAddData}
                style={{marginBottom: 20}}
            />
            <FlatList
                data={items}
                renderItem={renderItem}
                keyExtractor={(item)=>item.id}
            />
        </View>
    );

}
export default Slot16_1;