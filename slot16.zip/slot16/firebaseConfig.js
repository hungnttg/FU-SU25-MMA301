// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import {getStorage} from 'firebase/storage';
import {getAuth} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore';
import {getDatabase} from 'firebase/database';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "1AIzaSyBwpepe404aQiQN44h38SFSU_sHj0Eqi9c",
  authDomain: "hungnq40-fb6d81.firebaseapp.com",
  projectId: "hungnq40-fb6d18",
  storageBucket: "hungnq40-fb6d18.firebasestorage.app",
  messagingSenderId: "2328003816706",
  appId: "1:2328003867106:web:10ae0dd8189e7da440704b",
  measurementId: "G-LY02B2V0NK1"
};

// Initialize Firebase
export const FIREBASE_APP = initializeApp(firebaseConfig);
export const FIREBASE_AUTH = getAuth(FIREBASE_APP);
export const FIRESTORE_DB = getFirestore(FIREBASE_APP);
//const analytics = getAnalytics(FIREBASE_APP);
export const STORAGE = getStorage(FIREBASE_APP);
export const DATABASE = getDatabase(FIREBASE_APP);
//cai thu vien:
//npm install firebase
//npx expo install expo-dev-client
//npx expo install @react-native-firebase/app