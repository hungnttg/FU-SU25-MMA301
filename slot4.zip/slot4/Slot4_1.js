import React,{useState} from "react";
import { View,Text,StyleSheet,TouchableOpacity } from "react-native";
//Khai bao bien toan cuc
global.myVar="";
export default function Slot4_1(){
    //code===========
    //Khai bao bien, thuoc tinh
    const [phepTinh,setPhepTinh] = useState('pheptinh');
    const [ketQua,setKetQua]=useState('ketqua');
    let result="";
    let calculation="";
    //dinh nghia ham
    //--pressButton
    const pressButton = (text)=>{
        if(text==="="){//khi click vao dau =
            calculation = global.myVar;//cap nhat gia tri toan cuc vao bien calculation
            return calculationResult(calculation);//tinh toan gia tri bieu thuc
        }
        else { //khi click vao cac button khac => lay text dua vao bieu thuc
            //noi chuoi
            calculation = global.myVar;//nhan gia tri hien tai tu bien toan cuc
            calculation=calculation+text;//noi them text khi click button
            global.myVar = calculation;//cap nhat gia tri moi len bien toan cuc
            setPhepTinh(calculation);//cap nhat vao phan phep tinh

        }
    };
    // dinh nghia ham tinh toan ket qua
    const calculationResult = (text) =>{
        result = eval(text);//tinh toan ket qua
        global.myVar="";//xoa trang bien toan cuc (de sau khi tinh toan thi myVar reset)
        setKetQua(result);//cap nhat ket qua
    };
    //dinh nghia ham xu ly phep tinh
    const operate = (o) =>{
        switch(o){
            case 'DEL':
                let text = calculation.split('');//pha vo chuoi
                global.myVar = calculation;//cap nhat lai bien toan cuc
                text.pop();//xoa ky tu cuoi cung
                global.myVar = text; //cap nhat ket qua moi cho myVar
                calculation= text.join('');//hop cac phan tu con lai thanh chuoi
                calculation = global.myVar;
                setPhepTinh(calculation);
                break;
            case '+':
            case '-':
            case '*':
            case '/':
                calculation=global.myVar;//lay gia tri tu bien toan cuc
                calculation=calculation+o;//noi phep tinh vao bieu thuc
                global.myVar = calculation;//update len bien toan cuc
                setPhepTinh(calculation);
                break;

        }
    };
    //===============layout
    // ---- xu ly con so
    let rows=[];//khai bao mang rows
    let nums = [[1,2,3],[4,5,6],[7,8,9],['.','0','=']];//mang con so
    for(let i=0;i<4;i++){//4 dong i
        let row=[];//mang dong
        for(let j=0;j<3;j++){
            //dua cac con so vao dong
            row.push(
                <TouchableOpacity style={styles.btn} key={nums[i][j]}
                    onPress={()=>pressButton(nums[i][j])}
                >
                    <Text>{nums[i][j]}</Text>
                </TouchableOpacity>
            );
        }
        //chuyen row vao rows
        rows.push(
            <View key={i} style={styles.row} >{row}</View>
        );
    }
    // ----xu ly phep tinh
    let ops=[];//mang chua phep tinh
    let operator = ['+','-','*','/','DEL'];
    for(let i=0;i<5;i++){
        ops.push(
            <TouchableOpacity key={operator[i]} style={styles.btn}
                onPress={()=>operate(operator[i])}
            >
                <Text>{operator[i]}</Text>
            </TouchableOpacity>
        );
    }
    return(
        <View style={styles.container}>
            {/* result text */}
            <View style={styles.resultText}>
                <Text style={styles.txt}>{ketQua}</Text>
            </View>
            {/* calculation text */}
            <View style={styles.calculationText}>
                <Text style={styles.txt}>{phepTinh}</Text>
            </View>
            {/* button */}
            <View style={styles.buttons}>
                <View style={styles.numberButtons}>{rows}</View>
                <View style={styles.operationButtons}>{ops}</View>
            </View>
        </View>
    );

}
const styles = StyleSheet.create({
    container :{
        flex:1,
        flexDirection:'column',
        backgroundColor:'yellow',
    },
    // cac thanh phan con cua container
    resultText:{
        flex:1,
        backgroundColor:'green',
        justifyContent:'space-around',
        alignItems:'center',
    },
    calculationText:{
        flex:2,
        backgroundColor:'#AAA111',
        justifyContent:'space-around',
        alignItems:'center',
    },
    buttons:{
        flex:7,
        flexDirection:'row',
        backgroundColor:'pink',
    },
    // cac thanh phan con cua button
    numberButtons:{
        flex:3,
        backgroundColor:'#BBB111',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    operationButtons:{
        flex:1,
        backgroundColor:'#CCC111',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    // -----cac button (don vi nho nhat)
    btn:{
        flex:1,
        backgroundColor:'#DDD111',
        justifyContent:'center',
        alignItems:'center',
        fontSize:30,
    },
    txt:{
        fontSize:30,
        fontWeight:'bold',
    },
    row:{
        flex:1,
        flexDirection:'row',
        justifyContent:'space-around',
        alignItems:'stretch',
        fontSize:30,
        fontWeight:'bold'
    },
});