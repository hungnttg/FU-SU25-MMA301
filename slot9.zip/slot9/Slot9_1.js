import React from "react";
import { Text,View,StyleSheet } from "react-native";
const SectionView = ({title,children,backgroundColor}) =>{
    return(
        <View style={[styles.container,{backgroundColor}]}>
            <Text style={[styles.title]}>{title}</Text>
            {children}
        </View>
    );
};
const Slot9_1 = () =>{
    return(
        <View style={styles.container}>
            <SectionView title="Header" backgroundColor="#ccc">
                <Text>Header content goes here</Text>
            </SectionView>
            <SectionView title="Content" backgroundColor="#fffccc">
                <Text>Content goes here</Text>
            </SectionView>
            <SectionView title="Footer" backgroundColor="#fffddd">
                <Text>Footer content goes here</Text>
            </SectionView>
        </View>
    );
};
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    title:{
        fontSize:20,
        fontWeight:'bold',
        marginBottom:10,
    },
});
export default Slot9_1;