import React,{useState} from "react";
import { Text,TextInput,Button,View,StyleSheet } from "react-native";
const Slot9_3 = ()=>{
    const [inputValue,setInputValue]=useState('');
    const [isInputValid,setIsInputValid]=useState(true);
    const handleBlur = () =>{
        setIsInputValid(inputValue.trim() !== '');
    };
    const handleSubmit=()=>{
        setIsInputValid(inputValue.trim() !== '');
    };
    return(
        <View style={styles.container}>
            {/* nhap lieu */}
            <TextInput
                style={[styles.input, !isInputValid && styles.invalid]}
                placeholder="Nhap...."
                onChangeText={text =>{
                    setInputValue(text);
                    setIsInputValid(true);
                }}
                onBlur={handleBlur}
            />
            {/* dua ra thong bao loi */}
            {!isInputValid && <Text style={styles.errorText}>Vui long khong de trong</Text>}
            {/* button submit */}
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );
};
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
    },
    input:{
        borderWidth:1,
        borderColor:'#ccc',
        padding:10,
        marginBottom:10,
        width:'80%',
    },  
    invalid:{
        borderColor:'red',
    },
    errorText:{
        color:'red',
        marginBottom:10,
    },
});
export default Slot9_3;