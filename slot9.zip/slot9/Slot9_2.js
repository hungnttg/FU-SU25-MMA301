import React from "react";
import { Text,View,Image,StyleSheet } from "react-native";
const SectionView = ({title,imageSource,description})=>{
    return(
        <View style={styles.container}>
            <Text style={styles.title}>{title}</Text>
            <Image source={imageSource} style={styles.image}/>
            <Text style={styles.description}>{description}</Text>
        </View>
    );

};
const Slot9_2 = () =>{
    return(
        <View style={styles.container}>
            <SectionView
                title="Welcome"
                imageSource={{uri:'https://daihoc.fpt.edu.vn/wp-content/uploads/2023/04/cropped-cropped-2021-FPTU-Long.png'}}
                description="This is a welcome message"
            />
        </View>
    );
};
const styles = StyleSheet.create({
    container:{
        padding:20,
        backgroundColor:'#ffffff',
        borderRadius:10,
        shadowColor:'#000',
        shadowOffset: {width:0,height:2},
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation:5,
    },
    title:{
        fontSize:25,
        fontWeight:'bold',
        marginBottom:10,
    },
    image:{
        width:150,
        height:50,
        marginBottom:10,
        borderRadius:5,
    },
    description:{
        fontSize:15,
    },
});
export default Slot9_2;