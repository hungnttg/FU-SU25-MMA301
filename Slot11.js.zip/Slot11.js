//npm i @react-native-async-storage/async-storage
//layout HomeScreen
import React,{useState,useCallback,useEffect} from "react";
import { Text,View,TextInput,StyleSheet,Button,FlatList,TouchableOpacity } from "react-native";
import { createStackNavigator} from "@react-navigation/stack";
import { NavigationContainer,useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
const HomeScreen = ({navigation})=>{
    const [lands,setLands]=useState([]);
    const [search,setSearch]=useState('');//cho phep tim kiem
    // doc du lieu tu AsyncStorage va dua vao state lands
    useFocusEffect(
        useCallback(()=>{
            (async () => {
                const data = await AsyncStorage.getItem('lands');//lay ve cac manh dat da co
                setLands(data ? JSON.parse(data) : []);//dua du lieu doc duoc vao state
            })();
        },[])
    );
    // dien vao layout
    return(
        <View style={{flex:1,padding:10}}>
            {/* tao o tim kiem */}
            <TextInput placeholder="Tim kiem" onChangeText={setSearch}/>
            {/* dien du lieu tim duoc vao flatlist */}
            <FlatList
                data={lands.filter(l=>l.name?.includes(search) || l.location?.includes(search))}
                keyExtractor={(item) => item.id}
                renderItem={({item})=>(
                    <TouchableOpacity onPress={()=>navigation.navigate('Detail',{land:item})}>
                        <Text>{item.name} - {item.location}</Text>
                    </TouchableOpacity>
                )}
            />
            {/* button */}
            <Button title="Them" onPress={()=>navigation.navigate('Edit')} />
        </View>
    );
}
// LandScreen
const LandScreen = ({navigation,route})=>{
    // lay du lieu chuyen sang tu HomeScreen
    const [land,setLand]=useState(route.params?.land || 
        {id:Date.now().toString(),name:'',location:'',price:''});
    // ham luu du lieu vao AsyncStorage
    const saveLand = async () =>{
        //doc du lieu tu AsyncStorage
        const storedLands = JSON.parse(await AsyncStorage.getItem('lands'))||[];
        //luu du lieu vao cuoi cua mang
        await AsyncStorage.setItem('lands',JSON.stringify(route.params?.land ? 
            storedLands.map(l=>l.id === land.id ? land : l) : [...storedLands,land]
        ));
        //chuyen navigation
        navigation.goBack();
    };
    // layout
    return(
        <View style={{flex:1,padding:10}}>
            <TextInput placeholder="Ten" value={land.name} onChangeText={v=>setLand({...land,name:v})}/>
            <TextInput placeholder="Vi tri" value={land.location} onChangeText={v=>setLand({...land,location:v})}/>
            <TextInput placeholder="Gia" value={land.price} onChangeText={v=>setLand({...land,price:v})}
                keyboardType="numeric"
                />
            <Button title="Luu" onPress={saveLand}/>
        </View>
    );
}
// DetailScreen
const DetailScreen = ({route,navigation})=>{
    const {land} = route.params;
    // ham xoa san pham
    const deleteLand = async () =>{
        //doc du lieu tu asyncstorage
        const storedLand = JSON.parse(await AsyncStorage.getItem('lands'))||[];
        // tao 1 mang moi co id khac voi id can xoa (xoa san pham)
        await AsyncStorage.setItem('lands',JSON.stringify(storedLand.filter(l=>l.id !== land.id)));
        //navigate
        navigation.goBack();

    };
    // layout
    return(
        <View style={{flex:1, padding:10}}>
            <Text>{land.name}</Text>
            <Text>{land.location}</Text>
            <Text>{land.price}</Text>
            <Button title="Xoa" onPress={deleteLand}/>
            <Button title="Sua" onPress={()=>navigation.navigate('Edit',{land})}/>
        </View>
    );
};
const Stack = createStackNavigator();
export default function Slot11(){
    return(
        <Stack.Navigator initialRouteName="Home">
            <Stack.Screen name="Home" component={HomeScreen}/>
            <Stack.Screen name="Edit" component={LandScreen}/>
            <Stack.Screen name="Detail" component={DetailScreen}/>
        </Stack.Navigator>
    );
}