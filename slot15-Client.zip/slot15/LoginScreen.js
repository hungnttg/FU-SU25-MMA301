import React,{useState} from "react";
import { Text,View,TextInput,Button,StyleSheet } from "react-native";
import { loginUser } from "./api";
const LoginScreen = () =>{
    const [username,setUsername] = useState('');
    const [password,setPassword] = useState('');
    const [message,setMessage] = useState('');
    const [error,setError]=useState('');
    // ham login
    const handleLogin = async () => {
        setError('');
        setMessage('');
        try {
            const response = await loginUser(username,password);
            if(response.role){
                setMessage("dang nhap thanh cong");
                console.log(response);
            }
        } catch (error) {
            setError(error.message);
            console.error('Login failed: ',error);
        }
    };
    // giao dien
    return(
        <View>
            <Text>User Name</Text>
            <TextInput value={username} onChangeText={setUsername} placeholder="Username"
                style={{borderWidth:1}} />
            <Text>Password</Text>
            <TextInput value={password} onChangeText={setPassword} placeholder="Password"
                style={{borderWidth:1}} secureTextEntry />
            {/* thong bao loi */}
            {error ? <Text style={{color:'red'}}>{error}</Text> : <Text>{message}</Text>}
            {/* button */}
            <Button title="Login" onPress={handleLogin} />
        </View>
        
    );
};
export default LoginScreen;