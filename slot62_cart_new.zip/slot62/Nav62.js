import DetailSL62 from "./DetailSL62";
import ListProduct62 from "./ListProduct62";
import CartSL62 from "./CartSL6";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
//tao danh sach de hien thi
const Stack = createNativeStackNavigator();
const Nav62 = () =>{
    return(
        <Stack.Navigator initialRouteName="ListProduct62">
            <Stack.Screen name="ListProduct62" component={ListProduct62}/>
            <Stack.Screen name="DetailSL62" component={DetailSL62}/>
            <Stack.Screen name="CartSL62" component={CartSL62}/>
        </Stack.Navigator>
    );
    
}
export default Nav62;