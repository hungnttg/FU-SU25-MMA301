import React,{useState} from "react";
import { Text,View,ScrollView,Button,FlatList } from "react-native";
import ProductSL62 from "./ProductSL62";
global.mycart=[];//gio hang
const CartSL62 = ({route}) =>{
    //code
    const [count,setCount]=useState(1);//bien luu so luong san oham
    const [list,setList]=useState(global.mycart);//bien luu gio hang
    const data = route.params?.data || "";  //nhan du lieu tu detail
    // ham ket xuat du lieu item
    const renderItemCart = ({index,item}) =>{
        return(
            <ProductSL62 dataProd={global.mycart[index].data}/>
        );
    };
    const allProductOfCart = () =>{
        //them data vao global.mycart
        const newList = [{data},...global.mycart];
        //cap nhat du lieu moi them vao global
        global.mycart = newList;
        //cap nhat vao tranh thai list
        setList([...newList]);
    };
    //layout
    return(
        <View>
            <ScrollView>
                {/* hien thi du lieu can them vao gio hang */}
                <ProductSL62 dataProd={data}/>
            </ScrollView> 
            {/* tang giam so luong */}
            <Button title="+" onPress={()=>setCount(count+1)}/>
            <Text>So luong san pham: {count}</Text>
            <Button title="-" onPress={()=>setCount(count-1)}/>
            {/* button goi tat ca cacs san pham */}
            <Button title="Get All Cart" onPress={allProductOfCart}/>
            {/* hien thi */}
            <FlatList
                data={list}
                renderItem={renderItemCart}
                numColumns={2}
                removeClippedSubviews
            />
          
        </View>
       
    );
}
export default CartSL62;