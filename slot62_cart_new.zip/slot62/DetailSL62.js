import React from "react";
import { ScrollView,Button } from "react-native";
import ProductSL62 from "./ProductSL62";
const DetailSL62 = ({route,navigation}) =>{
    //code
    const data1 = route.params?.data || "";//nhan du lieu tu ListProduct chuyen sang
    //ham them san pham vao gio hang
    const addToCart = (d) =>{
        navigation.navigate('CartSL62',{data:d});
    };
    //layout
    return(
        <ScrollView>
            {/* hien thi du lieu chi tiet */}
            <ProductSL62 dataProd={data1}/>
            <Button title="Add to Cart" onPress={()=>addToCart(data1)}/>
        </ScrollView>
    );
}
export default DetailSL62;