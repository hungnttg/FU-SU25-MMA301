
import NavFn61 from '../../src/slot61/Nav61';
import Nav62 from '../../src/slot62/Nav62';
export default function HomeScreen() {
  return(
      <Nav62/>
    );
}
