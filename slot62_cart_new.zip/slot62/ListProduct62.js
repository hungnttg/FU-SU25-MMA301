//npm i @react-navigation/stack
//npm i @react-navigation/native
import React,{useState,useEffect} from "react";
import { FlatList } from "react-native";
import { useNavigation,useRoute } from "@react-navigation/native";
import ProductSL62 from "./ProductSL62";
const ListProduct62 = ()=>{
    //navigation
    const navigation = useNavigation();//dieu huong
    const route=useRoute();//truyen du lieu giua cac man hinh
    //code
    const [prd,setPrd] = useState(null);//state prd se nhan du lieu tu prop
    //ham render du lieu cho flatlist
    const renderItemFlatList = ({item}) =>{
        return(
            <ProductSL62 dataProd={item} handlePress={()=>viewDetail(item)} />
        );
    };
    //ham hien thi chi tiet san pham
    const viewDetail = (a)=>{
        navigation.navigate('DetailSL62',{data:a});
    };
    // viet ham doc du lieu tu server
    const getProducts = async () =>{
        const url='https://hungnttg.github.io/shopgiay.json';//url
        const response = await fetch(url,{method:'GET'});//doc du lieu
        const resonseJSON = await response.json();//chuyen sang json
        setPrd(resonseJSON.products);
    };
    //goi ham
    useEffect(()=>{
        getProducts();//thuc hien doc du lieu tu server
    },[]);
    //layout
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatList}
            numColumns={3}
            removeClippedSubviews
        />
    );
}
export default ListProduct62;