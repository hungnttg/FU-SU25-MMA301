const express = require('express');
const User = require('../model/User');
const router = express.Router();
//lay tat ca cac user
router.get('/',async (req,res)=>{
    try {
        res.json(await User.find());
    } catch (error) {
        res.status(500).json({message: error.message});
    }
});
//login
router.post('/login', async (req,res)=>{
    try {
        const user = await User.findOne({username: req.body.username});
        if(!user || user.password != req.body.password){
            return res.status(401).json({message: 'Invalid username or password'});
        }
        res.json({token: user.username, role: user.role});
    } catch (error) {
        res.status(500).json({message: error.message});
    }
});
module.exports = router;