//npm i mongoose
//npm i express
//npm i cors
//npm i body-parser
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const userRoutes = require('./routes/users');
const app = express();
mongoose.connect('mongodb://localhost:27017/a1',{
}).then(()=> console.log('da ket noi')).catch(err => console.log(err));
app.use(cors());
app.use(bodyParser.json());
//
app.use('/api/users',userRoutes);
app.listen(5001,()=>{
    console.log('Server dang chay o cong 5001');
});